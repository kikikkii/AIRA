const app = getApp()

Page({
  data: {
    winHeight: 0,
    rili: false,
    city: false,
    locateCity: '',
  },
  //监听传值，后面自己做处理了
  cityTap(e) {
    //console.log(e);
    const cityName = e.detail.cityname;
    // console.log('选择城市为：' + cityName);
    // console.log('此处选择后，跳转页面，将城市名传过去你需要的页面就行了');
    this.setData({
       city: false,
       locateCity: cityName
     });
  },
  /**
   * 生命周期函数--监听页面加载
   */
   showCity(){
     this.setData({
       city: true,

     });
   },
  onLoad: function (options) {
    const win = wx.getSystemInfoSync();

    this.setData({
      winHeight: win.windowHeight,
      locateCity: wx.getStorageSync('locatecity').city
    });

  }
})
